/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Dell
 */
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class login extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve user inputs from the form
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Here, you should perform authentication logic.
        // For simplicity, we'll use hardcoded values for username and password.
//        if ("your_username".equals(username) && "your_password".equals(password)) {
            // Authentication successful
            response.sendRedirect("Dashboard.jsp");
//        } else {
//            // Authentication failed, redirect back to login page with an error message
//            response.sendRedirect("login.jsp?error=true");
//        }
    }
}

