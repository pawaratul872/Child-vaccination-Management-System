/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        boolean isValidUser = authenticateUser(username, password);

        if (isValidUser) {
            // Redirect to a welcome page or perform other actions
            response.sendRedirect("welcome.jsp");
        } else {
            // Display an error message
            PrintWriter out = response.getWriter();
            out.println("Invalid login credentials. Please try again.");
        }
    }

    private boolean authenticateUser(String username, String password) {
        // Perform database authentication here
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/vaccinationdatabase","root", "Root");
            String query = "SELECT * FROM users WHERE username=? AND password=?";
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            ResultSet resultSet = preparedStatement.executeQuery();

            return resultSet.next(); // If a row is returned, the user is valid
        } catch (SQLException e) {
            return false;
        }
    }
}
